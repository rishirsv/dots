# Oracle context manifest

- Created (UTC): 2026-03-06T03:33:30.253378+00:00
- Repo root: /Users/rishi/Code/ai-tools
- Files included: 101
- Total raw size (before zip): 687.0 KB

## Task summary
Review the portable kpmg-slides skill as a shipped artifact, review the parent slidegen repo for correctness and production readiness, and propose a full implementation plan for end-to-end slide-layout onboarding from a PowerPoint file.

## Constraints / preferences
- Treat kpmg-utils/kpmg-slidegen/skills/kpmg-slides as the user-distributed artifact.
- Also review the parent repo as the source of truth for testing, QA, harness engineering, sync, and future layout automation.
- Assess correctness, code quality, architecture, portability, Python PEP8, shell quality, skill best practices, and production readiness.
- Optionally use official Anthropic or OpenAI documentation for best-practices cross-checks if helpful.

## How to verify locally
If you want to confirm the advice locally, these checks/commands are relevant:

- `node kpmg-utils/kpmg-slidegen/scripts/test-pr.mjs`
- `node kpmg-utils/kpmg-slidegen/scripts/test-nightly.mjs`
- `node kpmg-utils/kpmg-slidegen/scripts/test-dist.mjs`

## Excludes applied
- Default excluded directories: .git, .next, .pytest_cache, .turbo, __pycache__, build, coverage, dist, node_modules, tmp
- Default excluded file names: .DS_Store
- Custom exclude patterns:
  - `kpmg-utils/kpmg-slidegen/outputs/**`
  - `kpmg-utils/kpmg-slidegen/.agents/oracle/**/context.zip`
  - `**/*.png`
  - `**/*.jpg`
  - `**/*.jpeg`
  - `**/*.pptx`
  - `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/assets/slidegen/generator/**`

## Largest files (by raw size)
- `kpmg-utils/kpmg-slidegen/generator/runtime/render-deck.js` — 43.7 KB
- `kpmg-utils/kpmg-slidegen/generator/runtime/paginate.js` — 37.5 KB
- `kpmg-utils/kpmg-slidegen/generator/app/qa-report.js` — 26.4 KB
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/references/deckspec.schema.json` — 25.5 KB
- `kpmg-utils/kpmg-slidegen/generator/builders/analysis-narrow-table.js` — 23.9 KB

## Files
- `kpmg-utils/kpmg-slidegen/ARCHITECTURE.md` — Architecture and code organization overview
- `kpmg-utils/kpmg-slidegen/docs/exec-plans/active/agent-harness-engineering-plan.md` — Current harness engineering plan and intended direction
- `kpmg-utils/kpmg-slidegen/fixtures/harness/fixtures.manifest.json` — Harness fixture taxonomy and governance
- `kpmg-utils/kpmg-slidegen/fixtures/harness/invalid/legacy-nested-bullets/deckSpec.json` — Representative invalid fixture
- `kpmg-utils/kpmg-slidegen/fixtures/harness/reference-parity/business-overview-coffee/deckSpec.json` — Representative parity fixture
- `kpmg-utils/kpmg-slidegen/fixtures/harness/regression/analysis-wide-chart-table-overflow/deckSpec.json` — Representative pagination regression fixture
- `kpmg-utils/kpmg-slidegen/fixtures/harness/regression/nested-bullets-children/deckSpec.json` — Representative structure regression fixture
- `kpmg-utils/kpmg-slidegen/fixtures/harness/scenario/saas-mid-diligence/deckSpec.json` — Representative scenario fixture
- `kpmg-utils/kpmg-slidegen/fixtures/harness/stress/analysis-bridge-overflow/deckSpec.json` — Representative stress fixture
- `kpmg-utils/kpmg-slidegen/generator/app/artifacts.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/app/cli.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/app/postprocess.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/app/qa-report.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/app/strict-overflow.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/builders/analysis-bridge.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/builders/analysis-narrow-table.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/builders/analysis-wide-chart-text.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/builders/back-cover-slide.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/builders/business-overview.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/builders/contents-slide.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/builders/cover-slide.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/builders/divider-slide.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/builders/one-column-text.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/builders/title-strapline-4-boxes.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/builders/two-column-text.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/analysis-wide-layout.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/bridge-layout.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/bridge.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/bullets.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/business-structure.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/callouts.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/chart.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/geometry.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/layout.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/media.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/one-column-layout.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/pagination-constants.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/slide-components.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/svg.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/text.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/theme.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/title.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/helpers/two-column-layout.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/index.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/postprocess/slides-adapter.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/postprocess/slides-runtime/create_montage.py` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/postprocess/slides-runtime/ensure_raster_image.py` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/postprocess/slides-runtime/render_slides.py` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/postprocess/slides-runtime/slides_test.py` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/runtime/diagnostics.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/runtime/geometry-contract.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/runtime/paginate.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/runtime/pagination-policy.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/runtime/render-context.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/runtime/render-deck.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/runtime/slide-registry.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/runtime/template-contracts.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/runtime/template-package.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/runtime/template-roots.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/runtime/theme.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/runtime/verbosity-contract.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/strict/overlap.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/generator/tokens.js` — Parent generator implementation including runtime, QA, postprocess, and Python runtime
- `kpmg-utils/kpmg-slidegen/package.json` — Public command surface and test lanes
- `kpmg-utils/kpmg-slidegen/presets/authoring/concise.deckSpec.json` — Prepared verbosity and density authoring presets
- `kpmg-utils/kpmg-slidegen/presets/authoring/detailed.deckSpec.json` — Prepared verbosity and density authoring presets
- `kpmg-utils/kpmg-slidegen/presets/authoring/extensive.deckSpec.json` — Prepared verbosity and density authoring presets
- `kpmg-utils/kpmg-slidegen/presets/authoring/minimal.deckSpec.json` — Prepared verbosity and density authoring presets
- `kpmg-utils/kpmg-slidegen/presets/authoring/presets.manifest.json` — Prepared verbosity and density authoring presets
- `kpmg-utils/kpmg-slidegen/README.md` — Top-level project overview and user-facing workflow
- `kpmg-utils/kpmg-slidegen/scripts/harness/lib.mjs` — Harness support helpers for fixture generation and artifact inspection
- `kpmg-utils/kpmg-slidegen/scripts/new-layout.mjs` — Current layout-onboarding scaffold to critique and improve
- `kpmg-utils/kpmg-slidegen/scripts/support.mjs` — Shared script runner and repo-root resolution
- `kpmg-utils/kpmg-slidegen/scripts/sync-skill-bundle.mjs` — Skill sync pipeline from parent repo into portable bundle
- `kpmg-utils/kpmg-slidegen/scripts/test-contracts.mjs` — Contract lane for the rebuilt harness
- `kpmg-utils/kpmg-slidegen/scripts/test-dist.mjs` — Distribution lane for the rebuilt harness
- `kpmg-utils/kpmg-slidegen/scripts/test-fixtures.mjs` — Fixture governance lane for the rebuilt harness
- `kpmg-utils/kpmg-slidegen/scripts/test-nightly.mjs` — Nightly bundle lane for the rebuilt harness
- `kpmg-utils/kpmg-slidegen/scripts/test-onboarding.mjs` — Layout onboarding lane for the rebuilt harness
- `kpmg-utils/kpmg-slidegen/scripts/test-pr.mjs` — PR bundle lane for the rebuilt harness
- `kpmg-utils/kpmg-slidegen/scripts/test-render.mjs` — Render lane for the rebuilt harness
- `kpmg-utils/kpmg-slidegen/scripts/test-structure.mjs` — Structure lane for the rebuilt harness
- `kpmg-utils/kpmg-slidegen/scripts/test-visual.mjs` — Visual lane for the rebuilt harness
- `kpmg-utils/kpmg-slidegen/scripts/verify-skill-bundle.mjs` — Distribution verification and smoke checks
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/agents/openai.yaml` — Portable skill metadata for the packaged skill
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/assets/bundle-manifest.json` — Portable skill sync manifest
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/assets/templates/deckspec-starter.json` — Portable skill starter and preset deck specs
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/assets/templates/presets/concise.deckSpec.json` — Portable skill starter and preset deck specs
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/assets/templates/presets/detailed.deckSpec.json` — Portable skill starter and preset deck specs
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/assets/templates/presets/extensive.deckSpec.json` — Portable skill starter and preset deck specs
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/assets/templates/presets/minimal.deckSpec.json` — Portable skill starter and preset deck specs
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/assets/templates/presets/presets.manifest.json` — Portable skill starter and preset deck specs
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/references/charting-playbook.md` — Portable skill references and contracts
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/references/deckspec.schema.json` — Portable skill references and contracts
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/references/INDEX.md` — Portable skill references and contracts
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/references/layout-policy.md` — Portable skill references and contracts
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/references/quality_assurance.md` — Portable skill references and contracts
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/references/slide-contract.md` — Portable skill references and contracts
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/references/writing-standards.md` — Portable skill references and contracts
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/scripts/run_kpmg_slides.sh` — Portable skill runner entrypoint
- `kpmg-utils/kpmg-slidegen/skills/kpmg-slides/SKILL.md` — Portable skill instructions as distributed to users

## Notes
- `prompt.md` is intentionally excluded; paste it separately into ChatGPT Pro.
- Treat files as authoritative; prefer citing exact paths when making claims.

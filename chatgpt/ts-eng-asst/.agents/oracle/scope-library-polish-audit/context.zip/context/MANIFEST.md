# Oracle context manifest

- Created (UTC): 2026-02-06T22:45:56.624443+00:00
- Repo root: /Users/rishi/Code/ai-tools/chatgpt/ts-eng-asst
- Files included: 9
- Total raw size (before zip): 327.1 KB

## Task summary
Polish and restructure docs/issues.md into an executive-ready final document and perform deep scope-library audit across industries, classifying core vs optional vs deal-specific content with detailed evidence.

## Constraints / preferences
- Use only files in context.zip; cite file paths for concrete claims.
- Provide detailed audit documentation and explicit difference log.
- If any ambiguity is blocking, include Clarifications Needed before final recommendations.

## How to verify locally
If you want to confirm the advice locally, these checks/commands are relevant:

- `python3 scripts/check-system-prompt-contract.py --prompt dist/ts-engagement-assistant.md --max-chars 7200`
- `python3 scripts/check-scope-spelling.py`
- `python3 scripts/validate-scope-exports.py`

## Excludes applied
- Default excludes: disabled (`--no-default-excludes`).

## Largest files (by raw size)
- `dist/scope-library.json` — 189.1 KB
- `dist/el-generate.py` — 53.2 KB
- `dist/el-placeholder-schema.json` — 22.1 KB
- `docs/mining/audit-verification-results.md` — 20.2 KB
- `docs/issues.md` — 12.8 KB

## Files
- `AGENTS.md` — Project constraints and hygiene rules
- `dist/el-generate.py` — Generation and scope inclusion/exclusion logic
- `dist/el-placeholder-schema.json` — Industry list and variable model
- `dist/scope-library.json` — Primary scope source under audit
- `dist/scope-review-buckets.json` — Bucket mapping and alias/concept mapping
- `dist/ts-engagement-assistant.md` — Scope review behavior contract
- `docs/issues.md` — Current draft issues report to polish and verify
- `docs/mining/audit-mapping.md` — Mapping notes for mined-to-library translation
- `docs/mining/audit-verification-results.md` — Prior audit verification context

## Notes
- `prompt.md` is intentionally excluded; paste it separately into ChatGPT Pro.
- Treat files as authoritative; prefer citing exact paths when making claims.
